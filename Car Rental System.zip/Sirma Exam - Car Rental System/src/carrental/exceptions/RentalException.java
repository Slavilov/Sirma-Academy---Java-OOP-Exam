package carrental.exceptions;

public class RentalException extends RuntimeException  {
    public RentalException(String message) {
        super(message);
    }
}
